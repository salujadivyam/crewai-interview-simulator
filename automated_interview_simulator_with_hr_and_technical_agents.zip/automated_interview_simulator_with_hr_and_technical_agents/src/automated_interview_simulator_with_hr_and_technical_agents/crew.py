from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task


@CrewBase
class AutomatedInterviewSimulatorWithHrAndTechnicalAgentsCrew():
    """AutomatedInterviewSimulatorWithHrAndTechnicalAgents crew"""

    @agent
    def hr_interviewer(self) -> Agent:
        return Agent(
            config=self.agents_config['hr_interviewer'],
            
        )

    @agent
    def technical_interviewer(self) -> Agent:
        return Agent(
            config=self.agents_config['technical_interviewer'],
            
        )

    @agent
    def feedback_generator(self) -> Agent:
        return Agent(
            config=self.agents_config['feedback_generator'],
            
        )


    @task
    def conduct_behavioral_interview(self) -> Task:
        return Task(
            config=self.tasks_config['conduct_behavioral_interview'],
            tools=[],
        )

    @task
    def conduct_technical_interview(self) -> Task:
        return Task(
            config=self.tasks_config['conduct_technical_interview'],
            tools=[],
        )

    @task
    def generate_feedback_report(self) -> Task:
        return Task(
            config=self.tasks_config['generate_feedback_report'],
            tools=[],
        )


    @crew
    def crew(self) -> Crew:
        """Creates the AutomatedInterviewSimulatorWithHrAndTechnicalAgents crew"""
        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
